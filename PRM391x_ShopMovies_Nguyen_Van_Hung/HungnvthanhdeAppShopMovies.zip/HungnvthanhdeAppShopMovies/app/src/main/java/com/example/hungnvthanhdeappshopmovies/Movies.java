package com.example.hungnvthanhdeappshopmovies;

public class Movies {
    // Declare
    private String title;
    // Declare image
    private String image;
    // Declare price
    private String price;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
