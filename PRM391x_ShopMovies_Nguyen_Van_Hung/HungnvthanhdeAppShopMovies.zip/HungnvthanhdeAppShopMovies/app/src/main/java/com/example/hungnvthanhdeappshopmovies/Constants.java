package com.example.hungnvthanhdeappshopmovies;

class Constants {
    // this is used for startActivity for results when the user presses facebook
    static final int LOGIN_BUTTON = 0;
    // this is used for startActivity for results when the user presses google
    static final int SIGN_IN_BUTTON = 1;
}
